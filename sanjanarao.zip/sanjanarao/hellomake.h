#include <stdio.h>
#include <stdlib.h>
//void myPrintHelloMake(void);

void push();

void pop();

void empty();

void stack_full();

void stack_count();

void peep();

